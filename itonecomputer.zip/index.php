<?php
require_once('lib/class.database.php');
require_once('lib/class.paginations.php');
require_once('lib/class.post.php'); $obj_post = new Post();
require_once('lib/class.category.php'); $obj_category = new Category();
require_once('lib/class.page.php'); $obj_page = new Page();
require_once('lib/class.advertise.php'); $obj_adv = new Advertise();
require_once('lib/class.user.php'); $obj_user = new User();

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link href="<?php echo $obj_post->site_path(); ?>css/lightbox.css" rel="stylesheet" type="text/css" />
<script src="<?php echo $obj_post->site_path();?>js/jquery-1.7.2.min.js"></script>
<script src="<?php echo $obj_post->site_path();?>js/jquery.smooth-scroll.min.js"></script>
<script src="<?php echo $obj_post->site_path();?>js/lightbox.js"></script> 

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="<?php echo $obj_post->site_path(); ?>css/main.css">
<link rel="stylesheet" type="text/css" href="<?php echo $obj_post->site_path(); ?>css/style.css">
<!--Menu JQuery-->
<link href="<?php echo $obj_post->site_path(); ?>css/dcaccordion.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script type='text/javascript' src='<?php echo $obj_post->site_path(); ?>js/jquery.cookie.js'></script>
<script type='text/javascript' src='<?php echo $obj_post->site_path(); ?>js/jquery.hoverIntent.minified.js'></script>
<script type='text/javascript' src='<?php echo $obj_post->site_path(); ?>js/jquery.dcjqaccordion.2.7.min.js'></script>
<link href="<?php echo $obj_post->site_path(); ?>css/skins/blue.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $obj_post->site_path(); ?>css/skins/graphite.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $obj_post->site_path(); ?>css/skins/grey.css" rel="stylesheet" type="text/css" />





<script type="text/javascript">
$(document).ready(function($){

					$('#accordion-3').dcAccordion({
						eventType: 'click',
						autoClose: true,
						saveState: true,
						disableLink: false,
						showCount: false,
						speed: 'slow'
					});

});
</script>


<link href='http://fonts.googleapis.com/css?family=Source+Code+Pro|Open+Sans:300' rel='stylesheet' type='text/css'> 
<link rel="stylesheet" href="<?php echo $obj_post->site_path(); ?>css/bjqs.css">
<link rel="stylesheet" href="<?php echo $obj_post->site_path(); ?>css/slider.css">
<script src="http://code.jquery.com/jquery-1.7.1.min.js"></script>
<script src="<?php echo $obj_post->site_path(); ?>js/bjqs-1.3.min.js"></script>
<script class="secret-source">
        jQuery(document).ready(function($) {

          $('#banner-fade').bjqs({
            height      : 220,
            width       : 900,
            responsive  : true
          });

        });
</script>

<title>
	ITOne Computer
</title>


</head>
<!-- Facebook -->
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1&appId=151646268376400";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<body>
<div id="wrapper">
	<div id="nav">
		<div class="left">
			<ul>
				<li><a href="">Home</a></li>
				<li><a href="">Service</a></li>
				<li><a href="">Contact</a></li>
				<li><a href="">About</a></li>
			</ul>
		</div> <!--.right-->
		<div class="right">
			<ul>
				<li><a href="https://www.facebook.com/itonecomputer">Facebook</a></li>
				<li><a href="">Twitter</a></li>
			</ul>
		</div> <!--.left-->

	</div> <!--#nav-->
	<div id="header">
		<div class="logo">
			<a href="<?php echo $obj_post->site_path(); ?>"><img src="<?php echo $obj_post->site_path(); ?>img/logo.png" /></a>
		</div><!--.logo-->
		<div class="menu">
			<?php echo $obj_page->display(); ?>

		</div> <!--.menu-->
	</div> <!--#header-->

	<div id="slider">
		<div id="banner-fade">
			<ul class="bjqs">
	          <li><img src="<?php echo $obj_post->site_path(); ?>img/banner01.jpg"></li>
	          <li><img src="<?php echo $obj_post->site_path(); ?>img/banner02.jpg"></li>
	          <li><img src="<?php echo $obj_post->site_path(); ?>img/banner03.jpg"></li>
	        </ul>
    	</div>
	</div><!--#slider-->

	<div id="containter">
		<div id="content">
			<?php
				if(isset($_GET['category'])):
					if(isset($_GET['post'])){
						$post = $_GET['post'];
						echo $obj_post->single($post);

						$category = $_GET['category'];
						echo $obj_post->related($category,$post);
					}
					else{
					$category = $_GET['category'];
					echo $obj_post->display($category);
					}

				elseif(isset($_GET['page'])):
					$page = $_GET['page'];
					echo $obj_page->single($page);
				else:
					echo $obj_post->latest();
				endif;

				
			?>

		</div><!--#content-->
		<div id="sidebar">
			<?php echo $obj_category->display(); ?>

			<?php $obj_adv->display(); ?>

			<div style='margin-top:5px;'>
				<div class="fb-like-box" data-href="https://www.facebook.com/itonecomputer" data-width="270" data-show-faces="true" data-header="true" data-stream="false" data-show-border="true"></div>
			</div>

			<div style='margin-top:5px;'>
			<a href="http://info.flagcounter.com/ng9c"><img src="http://s11.flagcounter.com/mini/ng9c/bg_FFFFFF/txt_000000/border_CCCCCC/flags_0/" alt="Flag Counter" border="0"></a>
			</div>
		</div><!--#sidebar-->
		<div class="clear"></div>


	</div> <!--#container-->
	<div class="clear"></div>

	<div id="info">
		<ul>
			<li><img src="<?php echo $obj_post->site_path() ?>img/mail.png" /> info@itonecomputer.com</li>
			<li><a href=""><img src="img/twitter.png" /> @itonecomputer</a></li>
			<li style="float:right;"><img src="<?php echo $obj_post->site_path() ?>img/phone.png" /> 092 161 123</li>
		</ul>
	</div> <!--#info-->

	<div id="footer">
		<div class="line"></div>
		<div class="shadow"></div>

		<div class="copyright">
			ITOne Computer ©2013. All Right Reserved.
		</div><!--#copyright-->
	</div> <!--#footer-->
</div> <!--#wrapper-->
</body>
</html>