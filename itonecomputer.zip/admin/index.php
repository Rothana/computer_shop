<?php require_once('../lib/class.database.php'); require_once('templates/header.php'); require_once('templates/left.php'); ?>       

        <div id="content">
        	<div class='content-body'>
            	<h1>Welcome to ITOne Computer</h1>
            	
                
            </div>
        </div> <!--end of content -->
<?php require_once('templates/footer.php'); ?>